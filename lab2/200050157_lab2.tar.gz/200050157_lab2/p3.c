#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>

int main() {

    char* exec_name[51];        // limited by 50 chars [last is null-char]
    char* args[] = {NULL};

    pid_t pid;

    // execv vs execvp
    // https://stackoverflow.com/questions/55743496/difference-between-exec-execvp-execl-execv

    while(1) {
        while(wait(NULL)>0);        // wait for any child process(es) [in particular, the last executed one...]
        printf(">>> ");
        scanf("%s", exec_name);
        pid = fork();
        if(pid==0) {
            execv(exec_name, args);     // alternative: system(exec_name)
            exit(0);
        }
    }

}