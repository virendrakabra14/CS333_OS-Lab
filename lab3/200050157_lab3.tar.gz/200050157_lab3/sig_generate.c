#include <stdio.h>

#include <sys/types.h>               // man 2 kill
#include <signal.h>

#include <stdlib.h>


int main(int argc, char** argv) {

    pid_t pid = atoi(argv[1]);

    // https://www.csl.mtu.edu/cs4411.ck/www/NOTES/signal/kill.html

    kill(pid, SIGINT);
    printf("SIGINT signal sent to PID: %d\n", pid);
    sleep(5);

    kill(pid, SIGTERM);
    printf("SIGTERM signal sent to PID: %d\n", pid);
    sleep(5);
    
    kill(pid, 9);       // SIGKILL: 9
    printf("SIGKILL (9) signal sent to PID: %d\n", pid);

}